package com.coveros.demo.helloworld;

public class HelloWorld {

  public static void main(final String[] args) {
    System.out.println("Hello, World!");
  }

}
